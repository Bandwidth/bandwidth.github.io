# Create an Outbound Call and Speak a Sentence 

This is the complete program to create an outbound call then speak a sentence. For step-by-step instructions on how to create this program, visit dev.bandwidth.com. 